﻿using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.Request
{
    public class UpdateMenuRequest : CreateMenuRequest
    {
        [Required(ErrorMessageResourceName = "IdRequired", ErrorMessageResourceType = typeof(Common.Resources.Errors))]
        public Guid? Id { get; set; }
    }
}