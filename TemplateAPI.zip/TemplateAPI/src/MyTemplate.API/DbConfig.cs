﻿namespace $safeprojectname$;

public class DbConfig
{
    public string ConnectionString { get; set; }
}
