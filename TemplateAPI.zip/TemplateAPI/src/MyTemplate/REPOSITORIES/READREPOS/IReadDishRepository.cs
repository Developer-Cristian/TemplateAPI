﻿using $safeprojectname$.Models;
using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.Repositories.ReadRepos
{
    public interface IReadDishRepository : IReadGenericRepositoty<Dish>
    {
        Task<Dish> GetDishByNameAndMenuAsync(string name, Guid? menuId);
    }
}
