﻿using $safeprojectname$.Common.Models;

namespace $safeprojectname$.Repositories.ReadRepos
{
    public interface IReadGenericRepositoty<T>
        where T : class, IEntity
    {
        Task<IEnumerable<T>> FetchAllAsync();

        Task<T> GetAsync(Guid? id);
    }
}