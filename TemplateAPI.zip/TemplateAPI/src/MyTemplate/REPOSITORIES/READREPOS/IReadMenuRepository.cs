﻿using $safeprojectname$.Models;

namespace $safeprojectname$.Repositories.ReadRepos
{
    public interface IReadMenuRepository : IReadGenericRepositoty<Menu>
    {
    }
}
