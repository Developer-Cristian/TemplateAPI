﻿using $safeprojectname$.Models;

namespace $safeprojectname$.Repositories.ReadRepos
{
    public interface IReadDrinkRepository : IReadGenericRepositoty<Drink>
    {
        Task<Drink> GetDrinkByNameAndMenuAsync(string name, Guid? menuId);
    }
}
