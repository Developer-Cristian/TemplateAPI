﻿using $safeprojectname$.Models;
using $safeprojectname$.Repositories.ReadRepos;

namespace $safeprojectname$.Repositories.SaveRepos
{
    public interface ISaveDishRepository : ISaveGenericRepositoty<Dish>, IReadDishRepository
    {
    }
}
