﻿using $safeprojectname$.Models;
using $safeprojectname$.Repositories.ReadRepos;

namespace $safeprojectname$.Repositories.SaveRepos
{
    public interface ISaveMenuRepository : ISaveGenericRepositoty<Menu>, IReadMenuRepository
    {
    }
}
