﻿using System.ComponentModel.DataAnnotations;
using $safeprojectname$.Common.Models;

namespace $safeprojectname$.Repositories.SaveRepos
{
    public interface ISaveGenericRepositoty<T>
        where T : class, IEntity
    {
        Task<IEnumerable<ValidationResult>> SaveAsync(T entity);

        Task<IEnumerable<ValidationResult>> DelateAsync(Guid? id);
    }
}