﻿using $safeprojectname$.Models;
using $safeprojectname$.Services.ReadService;
using $safeprojectname$.Services.SaveServices;

namespace $safeprojectname$.Services.SaveService
{
    public interface ISaveDishService : ISaveGenericService<Dish>
    {
    }
}
