﻿using System.ComponentModel.DataAnnotations;
using $safeprojectname$.Common.Models;

namespace $safeprojectname$.Services.SaveServices
{
    public interface ISaveGenericService<T>
        where T : class, IEntity
    {
        Task<IEnumerable<ValidationResult>> SaveAsync(T entity);

        Task<IEnumerable<ValidationResult>> DelateAsync(Guid? id);
    }
}