﻿using $safeprojectname$.Models;
using $safeprojectname$.Services.SaveServices;

namespace $safeprojectname$.Services.SaveService
{
    public interface ISaveMenuService : ISaveGenericService<Menu>
    {
    }
}
