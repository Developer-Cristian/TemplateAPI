﻿using $safeprojectname$.Models;
using $safeprojectname$.Repositories.ReadRepos;
using $safeprojectname$.Services.ReadService;

namespace $safeprojectname$.Services.ReadServices.Impl
{
    public class ReadMenuService : IReadMenuService
    {
        private IReadMenuRepository _repository;

        public ReadMenuService(IReadMenuRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<Menu>> FetchAllAsync()
        {
            return await _repository.FetchAllAsync();
        }

        public async Task<Menu> GetAsync(Guid? id)
        {
            return await _repository.GetAsync(id);
        }
    }
}
