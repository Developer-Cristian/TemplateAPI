﻿using $safeprojectname$.Models;
using $safeprojectname$.Repositories.ReadRepos;
using $safeprojectname$.Services.ReadService;

namespace $safeprojectname$.Services.ReadServices.Impl
{
    public class ReadDishService : IReadDishService
    {
        private IReadDishRepository _repository;

        public ReadDishService(IReadDishRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<Dish>> FetchAllAsync()
        {
            return await _repository.FetchAllAsync();
        }

        public async Task<Dish> GetAsync(Guid? id)
        {
            return await _repository.GetAsync(id);
        }
    }
}
