﻿using $safeprojectname$.Common.Models;

namespace $safeprojectname$.Services.ReadService
{
    public interface IReadGenericService<T>
        where T : class, IEntity
    {
        Task<IEnumerable<T>> FetchAllAsync();

        Task<T> GetAsync(Guid? id);
    }
}