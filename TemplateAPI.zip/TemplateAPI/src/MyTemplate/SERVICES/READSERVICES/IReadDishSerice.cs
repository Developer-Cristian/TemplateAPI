﻿using $safeprojectname$.Models;

namespace $safeprojectname$.Services.ReadService
{
    public interface IReadDishService : IReadGenericService<Dish>
    {
    }
}
