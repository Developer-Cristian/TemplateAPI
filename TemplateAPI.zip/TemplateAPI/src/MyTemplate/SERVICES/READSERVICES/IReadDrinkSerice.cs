﻿using $safeprojectname$.Models;

namespace $safeprojectname$.Services.ReadService
{
    public interface IReadDrinkService : IReadGenericService<Drink>
    {
    }
}
