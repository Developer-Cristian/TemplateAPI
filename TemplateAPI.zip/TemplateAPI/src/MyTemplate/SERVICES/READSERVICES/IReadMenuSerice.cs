﻿using $safeprojectname$.Models;

namespace $safeprojectname$.Services.ReadService
{
    public interface IReadMenuService : IReadGenericService<Menu>
    {
    }
}
