﻿using $safeprojectname$.Models;

namespace MyTemplate.Models
{
    public class ModelBase : IEntity
    {
        public Guid? Id { get; set; }

        public DateTime? CreationDate { get; set; }
    }
}
