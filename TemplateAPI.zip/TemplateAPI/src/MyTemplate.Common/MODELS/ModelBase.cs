﻿using $safeprojectname$.Models;

namespace Template.Models
{
    public class ModelBase : IEntity
    {
        public Guid? Id { get; set; }

        public DateTime? CreationDate { get; set; }
    }
}
