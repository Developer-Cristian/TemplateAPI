﻿namespace $safeprojectname$.Models
{
    public enum DishType
    {
        appetizers = 0,

        first = 1,

        second = 2,

        dessert = 3,

        pizza = 4
    }
}
