﻿namespace $safeprojectname$.Models
{
    public interface IEntity { }
}
