using Microsoft.EntityFrameworkCore;
using Template.EntityFramework.Contexts;
using Template.EntityFramework.Repositories.ReadRepos;
using Template.EntityFramework.Repositories.SaveRepos;
using Template.Repositories.ReadRepos;
using Template.Repositories.SaveRepos;
using Template.Services.ReadService;
using Template.Services.ReadServices.Impl;
using Template.Services.SaveService;
using Template.Services.SaveServices.Impl;
using $safeprojectname$;
using $safeprojectname$.Mappers;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();

// Create configuration and User secret connection string
var config = builder.Configuration.AddUserSecrets<string>().Build();
var dbSettings = config.GetSection("database").Get<DbConfig>();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Add db context
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(dbSettings.ConnectionString));

#region Service

// Read

builder.Services.AddScoped<IReadDishService, ReadDishService>();
builder.Services.AddScoped<IReadDrinkService, ReadDrinkService>();
builder.Services.AddScoped<IReadMenuService, ReadMenuService>();

// Save

builder.Services.AddScoped<ISaveDishService, SaveDishService>();
builder.Services.AddScoped<ISaveDrinkService, SaveDrinkService>();
builder.Services.AddScoped<ISaveMenuService, SaveMenuService>();

#endregion

#region Repos

builder.Services.AddDbContext<ApplicationDbContext>(options =>
{
    options.UseSqlServer(config.GetSection("database").Get<DbConfig>().ConnectionString,
        // migrations will be created in the EntityFramework project
        x => x.MigrationsAssembly(System.Reflection.Assembly.GetAssembly(typeof(ApplicationDbContext)).GetName().Name));
}, contextLifetime: ServiceLifetime.Scoped);

builder.Services.AddDbContextFactory<ApplicationDbContext>(options =>
{
    options.UseSqlServer(config.GetSection("database").Get<DbConfig>().ConnectionString,
        // migrations will be created in the EntityFramework project
        x => x.MigrationsAssembly(System.Reflection.Assembly.GetAssembly(typeof(ApplicationDbContext)).GetName().Name));
}, ServiceLifetime.Scoped);

// Read

builder.Services.AddScoped<IReadDishRepository, ReadDishRepository>();
builder.Services.AddScoped<IReadDrinkRepository, ReadDrinkRepository>();
builder.Services.AddScoped<IReadMenuRepository, ReadMenuRepository>();

// Save

builder.Services.AddScoped<ISaveDishRepository, SaveDishRepository>();
builder.Services.AddScoped<ISaveDrinkRepository, SaveDrinkRepository>();
builder.Services.AddScoped<ISaveMenuRepository, SaveMenuRepository>();

#endregion

// Add for ignore possible object cycle 
builder.Services.AddControllers().AddNewtonsoftJson(options =>
    options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
);

builder.Services.AddAutoMapper(typeof(AutoMapperProfile));

// add services and repos
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();