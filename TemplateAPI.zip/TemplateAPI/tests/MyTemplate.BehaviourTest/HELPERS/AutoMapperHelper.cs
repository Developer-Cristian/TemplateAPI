﻿using AutoMapper;
using MyTemplate.Api.Mappers;

namespace VGC.Operations.Api.Integration.Tests.Helpers
{
    public static class AutoMapperHelper
    {
        public static IMapper GetConfiguration()
        {
            var config = new MapperConfiguration(cfg =>
            {

                cfg.AddProfile<AutoMapperProfile>();

            });

            return config.CreateMapper();
        }
    }
}