﻿using MyTemplate.Api.Controllers;
using MyTemplate.EntityFramework.Repositories.ReadRepos;
using MyTemplate.EntityFramework.Repositories.SaveRepos;
using MyTemplate.Services.ReadServices.Impl;
using MyTemplate.Services.SaveServices.Impl;
using VGC.Operations.Api.Integration.Tests.Helpers;

namespace $safeprojectname$.Controllers.InMemoryControllers
{
    public class InMemoryDishesController : InMemoryDb
    {
        protected readonly DishesController _sut;

        protected readonly SaveDishRepository _repos;
        protected readonly SaveDishService _saveService;
        protected readonly ReadDishService _readService;

        protected readonly ReadMenuRepository _readMenuRepos;
        protected readonly ReadMenuService _readMenuService;

        public InMemoryDishesController()
        {
            _repos = new SaveDishRepository(_context);

            _saveService = new SaveDishService(_repos);
            _readService = new ReadDishService(_repos);

            _readMenuService = new ReadMenuService(_readMenuRepos = new ReadMenuRepository(_context));

            _sut = new DishesController(_saveService, _readService, AutoMapperHelper.GetConfiguration(), _readMenuService);

            //var newIdentity = new GenericIdentity("user-name", "Bearer");
            //newIdentity.AddClaim(new Claim("tid", DataFakerHelper.TenantId));

            //Sut.ControllerContext = new ControllerContext
            //{
            //    HttpContext = new DefaultHttpContext
            //    {
            //        User = new ClaimsPrincipal(newIdentity)
            //    }
            //};
        }
    }
}
