﻿using MyTemplate.Api.Controllers;
using MyTemplate.EntityFramework.Repositories.ReadRepos;
using MyTemplate.EntityFramework.Repositories.SaveRepos;
using MyTemplate.Services.ReadServices.Impl;
using MyTemplate.Services.SaveServices.Impl;
using VGC.Operations.Api.Integration.Tests.Helpers;

namespace $safeprojectname$.Controllers.InMemoryControllers
{
    public class InMemoryDrinksController : InMemoryDb
    {
        protected readonly DrinksController _sut;

        protected readonly SaveDrinkRepository _repos;
        protected readonly SaveDrinkService _saveService;
        protected readonly ReadDrinkService _readService;

        protected readonly ReadMenuRepository _readMenuRepos;
        protected readonly ReadMenuService _readMenuService;

        public InMemoryDrinksController()
        {
            _repos = new SaveDrinkRepository(_context);

            _saveService = new SaveDrinkService(_repos);
            _readService = new ReadDrinkService(_repos);

            _readMenuService = new ReadMenuService(_readMenuRepos = new ReadMenuRepository(_context));

            _sut = new DrinksController(_saveService, _readService, AutoMapperHelper.GetConfiguration(), _readMenuService);

            //var newIdentity = new GenericIdentity("user-name", "Bearer");
            //newIdentity.AddClaim(new Claim("tid", DataFakerHelper.TenantId));

            //Sut.ControllerContext = new ControllerContext
            //{
            //    HttpContext = new DefaultHttpContext
            //    {
            //        User = new ClaimsPrincipal(newIdentity)
            //    }
            //};
        }
    }
}
