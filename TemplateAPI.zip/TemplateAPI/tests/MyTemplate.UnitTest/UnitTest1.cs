namespace $safeprojectname$
{
    public class UnitTest1
    {
    }
}